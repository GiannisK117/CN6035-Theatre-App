require("dotenv").config();

const express = require("express");
const cors = require("cors");

const app = express();

require("./db/db");

const authRoutes = require("./routes/authRoutes");
const showRoutes = require("./routes/showRoutes");
const reservationRoutes =
require("./routes/reservationRoutes");

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/shows", showRoutes);
app.use("/api", reservationRoutes);

app.get("/", (req, res) => {
    res.send("API is running");
});

const PORT = 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});