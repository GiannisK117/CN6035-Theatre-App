const express = require("express");

const router = express.Router();

const {
    getShows,
    getShowtimes
} = require("../controllers/showController");

router.get("/", getShows);

router.get(
    "/:showId/showtimes",
    getShowtimes
);

module.exports = router;