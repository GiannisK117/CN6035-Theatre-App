const express = require("express");

const router = express.Router();

const verifyToken = require("../middleware/authMiddleware");

const {
    createReservation,
    getUserReservations,
    cancelReservation
} = require("../controllers/reservationController");

router.post(
    "/reservations",
    verifyToken,
    createReservation
);

router.get(
    "/user/reservations",
    verifyToken,
    getUserReservations
);

router.delete(
    "/reservations/:id",
    verifyToken,
    cancelReservation
);

module.exports = router;