const jwt = require("jsonwebtoken");

const verifyToken = (
    req,
    res,
    next
) => {

    const authHeader =
        req.headers.authorization;

    console.log("AUTH HEADER:");
    console.log(authHeader);

    if (!authHeader) {

        return res.status(401).json({
            message: "Access denied"
        });
    }

    const token =
        authHeader.split(" ")[1];

    console.log("TOKEN:");
    console.log(token);

    try {

        const verified = jwt.verify(
            token,
            process.env.JWT_SECRET
        );

        console.log("VERIFIED:");
        console.log(verified);

        req.user = verified;

        next();

    } catch (error) {

        console.log("JWT ERROR:");
        console.log(error);

        res.status(401).json({
            message: "Invalid token"
        });
    }
};

module.exports = verifyToken;