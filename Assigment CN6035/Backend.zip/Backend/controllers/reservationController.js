const db = require("../db/db");

const createReservation = (req, res) => {

    const { showtime_id, tickets } = req.body;

    const user_id = req.user.id;

    const checkSql = `
        SELECT available_seats
        FROM showtimes
        WHERE id = ?
    `;

    db.query(
        checkSql,
        [showtime_id],
        (err, results) => {

            if (err) {

                console.log(err);

                return res.status(500).json({
                    message: "Server error"
                });
            }

            if (results.length === 0) {

                return res.status(404).json({
                    message: "Showtime not found"
                });
            }

            const availableSeats =
                results[0].available_seats;

            if (tickets > availableSeats) {

                return res.status(400).json({
                    message:
                    "Not enough seats available"
                });
            }

            const reservationSql = `
                INSERT INTO reservations
                (user_id, showtime_id, tickets)
                VALUES (?, ?, ?)
            `;

            db.query(
                reservationSql,
                [user_id, showtime_id, tickets],
                (err, result) => {

                    if (err) {

                        console.log(err);

                        return res.status(500).json({
                            message:
                            "Reservation failed"
                        });
                    }

                    const updateSql = `
                        UPDATE showtimes
                        SET available_seats =
                        available_seats - ?
                        WHERE id = ?
                    `;

                    db.query(
                        updateSql,
                        [tickets, showtime_id]
                    );

                    console.log(
                        "RESERVATION INSERTED"
                    );

                    console.log(
                        "USER ID:",
                        user_id
                    );

                    console.log(
                        "SHOWTIME ID:",
                        showtime_id
                    );

                    console.log(
                        "TICKETS:",
                        tickets
                    );

                    res.status(201).json({
                        message:
                        "Reservation created successfully"
                    });
                }
            );
        }
    );
};

const getUserReservations = (req, res) => {

    const user_id = req.user.id;

    const sql = `
        SELECT
            reservations.id,
            reservations.tickets,
            reservations.reservation_date,
            shows.title,
            showtimes.show_date
        FROM reservations

        JOIN showtimes
        ON reservations.showtime_id =
        showtimes.id

        JOIN shows
        ON showtimes.show_id = shows.id

        WHERE reservations.user_id = ?
    `;

    db.query(sql, [user_id], (err, results) => {

        if (err) {

            console.log(err);

            return res.status(500).json({
                message: "Server error"
            });
        }

        console.log("REQ USER:");
        console.log(req.user);

        console.log("USER ID:");
        console.log(user_id);

        console.log("RESERVATIONS:");
        console.log(results);

        res.json(results);
    });
};

const cancelReservation = (req, res) => {

    const reservationId = req.params.id;

    const user_id = req.user.id;

    const getReservationSql = `
        SELECT showtime_id, tickets
        FROM reservations
        WHERE id = ? AND user_id = ?
    `;

    db.query(
        getReservationSql,
        [reservationId, user_id],
        (err, results) => {

            if (err) {

                console.log(err);

                return res.status(500).json({
                    message: "Server error"
                });
            }

            if (results.length === 0) {

                return res.status(404).json({
                    message:
                    "Reservation not found"
                });
            }

            const showtime_id =
                results[0].showtime_id;

            const tickets =
                results[0].tickets;

            const deleteSql = `
                DELETE FROM reservations
                WHERE id = ? AND user_id = ?
            `;

            db.query(
                deleteSql,
                [reservationId, user_id],
                (err, result) => {

                    if (err) {

                        console.log(err);

                        return res.status(500).json({
                            message:
                            "Cancellation failed"
                        });
                    }

                    const updateSeatsSql = `
                        UPDATE showtimes
                        SET available_seats =
                        available_seats + ?
                        WHERE id = ?
                    `;

                    db.query(
                        updateSeatsSql,
                        [tickets, showtime_id]
                    );

                    res.json({
                        message:
                        "Reservation cancelled"
                    });
                }
            );
        }
    );
};

module.exports = {
    createReservation,
    getUserReservations,
    cancelReservation
};