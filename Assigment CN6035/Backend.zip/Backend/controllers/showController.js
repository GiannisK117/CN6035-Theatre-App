const db = require("../db/db");

const getShows = (req, res) => {

    const sql = `
        SELECT 
            shows.id,
            shows.title,
            shows.description,
            shows.duration,
            shows.age_rating,
            theatres.name AS theatre_name,
            theatres.location
        FROM shows
        JOIN theatres
        ON shows.theatre_id = theatres.id
    `;

    db.query(sql, (err, results) => {

        if (err) {
            return res.status(500).json({
                message: "Error fetching shows"
            });
        }

        res.json(results);
    });
};

const getShowtimes = (req, res) => {

    const { showId } = req.params;

    const sql = `
        SELECT *
        FROM showtimes
        WHERE show_id = ?
    `;

    db.query(sql, [showId], (err, results) => {

        if (err) {
            return res.status(500).json({
                message: "Error fetching showtimes"
            });
        }

        res.json(results);
    });
};

module.exports = {
    getShows,
    getShowtimes
};