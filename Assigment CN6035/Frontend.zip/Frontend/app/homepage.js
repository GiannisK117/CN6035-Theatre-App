import React, {
  useEffect,
  useState,
} from "react";

import { useRouter }
from "expo-router";

import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from "react-native";

import axios from "axios";

export default function Homepage() {

  const [shows, setShows] =
    useState([]);

  const router = useRouter();

  useEffect(() => {
    fetchShows();
  }, []);

  const fetchShows = async () => {

    try {

      const response = await axios.get(
        "http://192.168.1.203:5000/api/shows"
      );

      setShows(response.data);

    } catch (error) {

      console.log(
        error.response?.data ||
        error.message
      );
    }
  };

  const handleLogout = () => {

    localStorage.removeItem(
      "token"
    );

    router.replace("/login");
  };

  return (

    <View style={styles.container}>

      <TouchableOpacity
        style={styles.logoutButton}
        onPress={handleLogout}
      >
        <Text style={styles.logoutText}>
          Logout
        </Text>
      </TouchableOpacity>

      <Text style={styles.title}>
        Theatre Shows
      </Text>

      <TouchableOpacity
        style={styles.reservationButton}
        onPress={() =>
          router.push("/reservations")
        }
      >
        <Text style={styles.buttonText}>
          My Reservations
        </Text>
      </TouchableOpacity>

      <FlatList
        data={shows}
        keyExtractor={(item) =>
          item.id.toString()
        }
        renderItem={({ item }) => (

          <View style={styles.card}>

            <Text style={styles.movie}>
              {item.title}
            </Text>

            <Text style={styles.description}>
              {item.description}
            </Text>

            <Text style={styles.info}>
              Duration:
              {" "}
              {item.duration} mins
            </Text>

            <Text style={styles.info}>
              Age Rating:
              {" "}
              {item.age_rating}
            </Text>

            <Text style={styles.info}>
              Theatre:
              {" "}
              {item.theatre_name}
            </Text>

            <TouchableOpacity
              style={styles.button}
              onPress={() =>
                router.push({
                  pathname:
                    "/showtimes",

                  params: {
                    showId: item.id,
                  },
                })
              }
            >
              <Text style={styles.buttonText}>
                View Showtimes
              </Text>
            </TouchableOpacity>

          </View>
        )}
      />

    </View>
  );
}
const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#121826",
    padding: 20,
    paddingTop: 55,
  },

  logoutButton: {
    alignSelf: "flex-end",
    backgroundColor: "#DC2626",
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 12,
    marginBottom: 15,
  },

  logoutText: {
    color: "#FFFFFF",
    fontWeight: "bold",
    fontSize: 14,
  },

  reservationButton: {
    backgroundColor: "#2563EB",
    padding: 16,
    borderRadius: 14,
    marginBottom: 25,
  },

  title: {
    fontSize: 34,
    fontWeight: "bold",
    marginBottom: 25,
    textAlign: "center",
    color: "#FFFFFF",
    letterSpacing: 1,
  },

  card: {
    backgroundColor: "#1E293B",
    padding: 22,
    borderRadius: 18,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#334155",
  },

  movie: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 12,
    color: "#FFFFFF",
  },

  description: {
    fontSize: 15,
    marginBottom: 18,
    color: "#CBD5E1",
    lineHeight: 22,
  },

  info: {
    fontSize: 15,
    marginBottom: 10,
    color: "#94A3B8",
  },

  button: {
    marginTop: 18,
    backgroundColor: "#2563EB",
    padding: 15,
    borderRadius: 12,
  },

  buttonText: {
    color: "#FFFFFF",
    textAlign: "center",
    fontWeight: "bold",
    fontSize: 16,
  },

});