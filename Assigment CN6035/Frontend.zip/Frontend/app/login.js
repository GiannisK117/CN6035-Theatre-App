import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";

import { useState } from "react";

import axios from "axios";

import { useRouter } from "expo-router";

export default function LoginScreen() {

  const router = useRouter();

  const [email, setEmail] =
    useState("");

  const [password, setPassword] =
    useState("");

  const handleLogin = async () => {

    try {

      const response = await axios.post(
        "http://192.168.1.203:5000/api/auth/login",
        {
          email,
          password,
        }
      );

      const token =
        response.data.token
          .replace(/'/g, "")
          .trim();

      console.log("RAW TOKEN:");
      console.log(token);

      localStorage.setItem(
        "token",
        token.replace(/'/g, "")
      );

      Alert.alert(
        "Success",
        "Login successful"
      );

      router.replace("/homepage");

    } catch (error) {

      console.log(error);

      Alert.alert(
        "Error",
        error.response?.data?.message ||
        "Login failed"
      );
    }
  };

  return (

    <View style={styles.container}>

      <Text style={styles.title}>
        Cinema Booking Login
      </Text>

      <TextInput
        placeholder="Email"
        style={styles.input}
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        placeholder="Password"
        secureTextEntry
        style={styles.input}
        value={password}
        onChangeText={setPassword}
      />

      <TouchableOpacity
        style={styles.button}
        onPress={handleLogin}
      >
        <Text style={styles.buttonText}>
          Login
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() =>
          router.push("/register")
        }
      >
        <Text style={styles.link}>
          Create Account
        </Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: "center",
    padding: 25,
    backgroundColor: "#121826",
  },

  title: {
    fontSize: 34,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 40,
    color: "#FFFFFF",
    letterSpacing: 1,
  },

  input: {
    backgroundColor: "#1E293B",
    borderWidth: 1,
    borderColor: "#334155",
    padding: 16,
    borderRadius: 12,
    marginBottom: 18,
    color: "#FFFFFF",
    fontSize: 16,
  },

  button: {
    backgroundColor: "#2563EB",
    padding: 16,
    borderRadius: 12,
    marginTop: 10,
  },

  buttonText: {
    color: "#FFFFFF",
    textAlign: "center",
    fontWeight: "bold",
    fontSize: 16,
  },

  link: {
    marginTop: 25,
    textAlign: "center",
    color: "#60A5FA",
    fontSize: 15,
  },

});