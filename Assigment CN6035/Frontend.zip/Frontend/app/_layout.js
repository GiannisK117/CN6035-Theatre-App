import { Stack } from "expo-router";

<Stack.Screen
  name="reservations"
  options={{ title: "My Reservations" }}
/>

export default function RootLayout() {
  <Stack.Screen
    name="showtimes"
    options={{ title: "Showtimes" }}
  />
  return (
    <Stack>

      <Stack.Screen
        name="login"
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name="register"
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name="homepage"
        options={{ title: "Theatre Shows" }}
      />

    </Stack>
  );
}