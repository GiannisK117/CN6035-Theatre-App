import React, {
  useEffect,
  useState,
} from "react";

import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from "react-native";

import axios from "axios";

export default function ReservationsScreen() {

  const [reservations, setReservations] =
    useState([]);

  useEffect(() => {
    fetchReservations();
  }, []);

  const fetchReservations = async () => {

    try {

      const token =
        localStorage.getItem("token");

      const response = await axios.get(
        "http://192.168.1.203:5000/api/user/reservations",
        {
          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

      setReservations(response.data);

    } catch (error) {

      console.log(
        error.response?.data ||
        error.message
      );
    }
  };

  const cancelReservation = async (
    reservationId
  ) => {

    try {

      const token =
        localStorage.getItem("token");

      const response =
        await axios.delete(
          `http://192.168.1.203:5000/api/reservations/${reservationId}`,
          {
            headers: {
              Authorization:
                `Bearer ${token}`,
            },
          }
        );

      Alert.alert(
        "Success",
        response.data.message
      );

      fetchReservations();

    } catch (error) {

      Alert.alert(
        "Error",
        error.response?.data?.message ||
        "Cancellation failed"
      );
    }
  };

  return (

    <View style={styles.container}>

      <Text style={styles.title}>
        My Reservations
      </Text>

      <FlatList
        data={reservations}
        keyExtractor={(item) =>
          item.id.toString()
        }
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={

          <Text style={styles.empty}>
            No reservations found
          </Text>
        }

        renderItem={({ item }) => (

          <View style={styles.card}>

            <Text style={styles.show}>
              {item.title}
            </Text>

            <Text style={styles.info}>
              Tickets: {item.tickets}
            </Text>

            <Text style={styles.info}>
              Show Date:
              {" "}
              {new Date(
                item.show_date
              ).toLocaleString()}
            </Text>

            <TouchableOpacity
              style={styles.button}
              onPress={() =>
                cancelReservation(item.id)
              }
            >

              <Text style={styles.buttonText}>
                Cancel Reservation
              </Text>

            </TouchableOpacity>

          </View>
        )}
      />

    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#121826",
    padding: 20,
    paddingTop: 50,
  },

  title: {
    fontSize: 34,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 25,
    color: "#FFFFFF",
    letterSpacing: 1,
  },

  empty: {
    textAlign: "center",
    fontSize: 18,
    marginTop: 70,
    color: "#94A3B8",
  },

  card: {
    backgroundColor: "#1E293B",
    padding: 22,
    borderRadius: 18,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#334155",
  },

  show: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 15,
    color: "#FFFFFF",
  },

  info: {
    fontSize: 15,
    marginBottom: 10,
    color: "#CBD5E1",
    lineHeight: 22,
  },

  button: {
    backgroundColor: "#DC2626",
    padding: 15,
    borderRadius: 12,
    marginTop: 18,
  },

  buttonText: {
    color: "#FFFFFF",
    textAlign: "center",
    fontWeight: "bold",
    fontSize: 15,
  },

});