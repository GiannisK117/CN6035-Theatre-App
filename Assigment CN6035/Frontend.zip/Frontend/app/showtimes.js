import React, {
    useEffect,
    useState,
} from "react";

import {
    View,
    Text,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    Alert,
} from "react-native";

import axios from "axios";

import { useLocalSearchParams }
from "expo-router";

export default function ShowtimesScreen() {

    const { showId } =
        useLocalSearchParams();

    const [showtimes, setShowtimes] =
        useState([]);

    const [ticketCounts, setTicketCounts] =
        useState({});

    useEffect(() => {
        fetchShowtimes();
    }, []);

    const fetchShowtimes = async () => {

        try {

            const response = await axios.get(
                `http://192.168.1.203:5000/api/shows/${showId}/showtimes`
            );

            setShowtimes(response.data);

        } catch (error) {

            console.log(
                error.response?.data ||
                error.message
            );
        }
    };

    const increaseTickets = (
        showtimeId,
        availableSeats
    ) => {

        setTicketCounts((prev) => {

            const current =
                prev[showtimeId] || 1;

            if (current >= availableSeats) {
                return prev;
            }

            return {
                ...prev,
                [showtimeId]: current + 1,
            };
        });
    };

    const decreaseTickets = (
        showtimeId
    ) => {

        setTicketCounts((prev) => ({

            ...prev,

            [showtimeId]:
                Math.max(
                    1,
                    (prev[showtimeId] || 1) - 1
                ),
        }));
    };

    const reserveSeats = async (
        showtimeId
    ) => {

        try {

            const token =
                localStorage.getItem("token");

            const tickets =
                ticketCounts[showtimeId] || 1;

            const response =
                await axios.post(
                    "http://192.168.1.203:5000/api/reservations",
                    {
                        showtime_id: showtimeId,
                        tickets,
                    },
                    {
                        headers: {
                            Authorization:
                                `Bearer ${token}`,
                        },
                    }
                );

            Alert.alert(
                "Success",
                response.data.message
            );

            fetchShowtimes();

        } catch (error) {

            console.log(
                error.response?.data ||
                error.message
            );

            Alert.alert(
                "Error",
                error.response?.data?.message ||
                "Reservation failed"
            );
        }
    };

    return (

        <View style={styles.container}>

            <Text style={styles.title}>
                Showtimes
            </Text>

            <FlatList
                data={showtimes}
                keyExtractor={(item) =>
                    item.id.toString()
                }
                showsVerticalScrollIndicator={false}
                renderItem={({ item }) => {

                    const tickets =
                        ticketCounts[item.id] || 1;

                    return (

                        <View style={styles.card}>

                            <Text style={styles.date}>
                                {new Date(
                                    item.show_date
                                ).toLocaleString()}
                            </Text>

                            <Text style={styles.info}>
                                Available Seats:
                                {" "}
                                {item.available_seats}
                            </Text>

                            <View style={styles.ticketContainer}>

                                <TouchableOpacity
                                    style={styles.ticketButton}
                                    onPress={() =>
                                        decreaseTickets(item.id)
                                    }
                                >
                                    <Text style={styles.ticketButtonText}>
                                        −
                                    </Text>
                                </TouchableOpacity>

                                <Text style={styles.ticketCount}>
                                    {tickets}
                                </Text>

                                <TouchableOpacity
                                    style={[
                                        styles.ticketButton,

                                        tickets >=
                                        item.available_seats &&

                                        styles.disabledTicketButton
                                    ]}
                                    disabled={
                                        tickets >=
                                        item.available_seats
                                    }
                                    onPress={() =>
                                        increaseTickets(
                                            item.id,
                                            item.available_seats
                                        )
                                    }
                                >
                                    <Text style={styles.ticketButtonText}>
                                        +
                                    </Text>
                                </TouchableOpacity>

                            </View>

                            <TouchableOpacity
                                disabled={
                                    item.available_seats <= 0
                                }
                                style={[
                                    styles.reserveButton,

                                    item.available_seats <= 0 &&

                                    styles.disabledButton
                                ]}
                                onPress={() =>
                                    reserveSeats(item.id)
                                }
                            >

                                <Text style={styles.reserveButtonText}>

                                    {item.available_seats <= 0

                                        ? "Sold Out"

                                        : `Reserve ${tickets} Seat${tickets > 1 ? "s" : ""}`}

                                </Text>

                            </TouchableOpacity>

                        </View>
                    );
                }}
            />

        </View>
    );
}

const styles = StyleSheet.create({

    container: {
        flex: 1,
        backgroundColor: "#121826",
        padding: 20,
        paddingTop: 50,
    },

    title: {
        fontSize: 34,
        fontWeight: "bold",
        color: "#FFFFFF",
        textAlign: "center",
        marginBottom: 25,
        letterSpacing: 1,
    },

    card: {
        backgroundColor: "#1E293B",
        padding: 22,
        borderRadius: 18,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: "#334155",
    },

    date: {
        color: "#FFFFFF",
        fontSize: 18,
        fontWeight: "bold",
        marginBottom: 12,
    },

    info: {
        color: "#CBD5E1",
        fontSize: 15,
        marginBottom: 10,
    },

    ticketContainer: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        marginTop: 18,
        marginBottom: 20,
    },

    ticketButton: {
        backgroundColor: "#2563EB",
        width: 45,
        height: 45,
        borderRadius: 22,
        justifyContent: "center",
        alignItems: "center",
    },

    disabledTicketButton: {
        backgroundColor: "#475569",
    },

    ticketButtonText: {
        color: "#FFFFFF",
        fontSize: 24,
        fontWeight: "bold",
    },

    ticketCount: {
        color: "#FFFFFF",
        fontSize: 24,
        fontWeight: "bold",
        marginHorizontal: 28,
    },

    reserveButton: {
        backgroundColor: "#2563EB",
        padding: 16,
        borderRadius: 12,
        marginTop: 5,
    },

    disabledButton: {
        backgroundColor: "#475569",
    },

    reserveButtonText: {
        color: "#FFFFFF",
        textAlign: "center",
        fontWeight: "bold",
        fontSize: 16,
    },

});